/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.7-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: laravel
-- ------------------------------------------------------
-- Server version	11.4.7-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES
('iucn-red-list-cache-iucn.countries','a:250:{i:0;a:2:{s:4:\"code\";s:2:\"AD\";s:4:\"name\";s:7:\"Andorra\";}i:1;a:2:{s:4:\"code\";s:2:\"AE\";s:4:\"name\";s:20:\"United Arab Emirates\";}i:2;a:2:{s:4:\"code\";s:2:\"AF\";s:4:\"name\";s:11:\"Afghanistan\";}i:3;a:2:{s:4:\"code\";s:2:\"AG\";s:4:\"name\";s:19:\"Antigua and Barbuda\";}i:4;a:2:{s:4:\"code\";s:2:\"AI\";s:4:\"name\";s:8:\"Anguilla\";}i:5;a:2:{s:4:\"code\";s:2:\"AL\";s:4:\"name\";s:7:\"Albania\";}i:6;a:2:{s:4:\"code\";s:2:\"AM\";s:4:\"name\";s:7:\"Armenia\";}i:7;a:2:{s:4:\"code\";s:2:\"AO\";s:4:\"name\";s:6:\"Angola\";}i:8;a:2:{s:4:\"code\";s:2:\"AQ\";s:4:\"name\";s:10:\"Antarctica\";}i:9;a:2:{s:4:\"code\";s:2:\"AR\";s:4:\"name\";s:9:\"Argentina\";}i:10;a:2:{s:4:\"code\";s:2:\"AS\";s:4:\"name\";s:14:\"American Samoa\";}i:11;a:2:{s:4:\"code\";s:2:\"AT\";s:4:\"name\";s:7:\"Austria\";}i:12;a:2:{s:4:\"code\";s:2:\"AU\";s:4:\"name\";s:9:\"Australia\";}i:13;a:2:{s:4:\"code\";s:2:\"AW\";s:4:\"name\";s:5:\"Aruba\";}i:14;a:2:{s:4:\"code\";s:2:\"AX\";s:4:\"name\";s:14:\"Åland Islands\";}i:15;a:2:{s:4:\"code\";s:2:\"AZ\";s:4:\"name\";s:10:\"Azerbaijan\";}i:16;a:2:{s:4:\"code\";s:2:\"BA\";s:4:\"name\";s:22:\"Bosnia and Herzegovina\";}i:17;a:2:{s:4:\"code\";s:2:\"BB\";s:4:\"name\";s:8:\"Barbados\";}i:18;a:2:{s:4:\"code\";s:2:\"BD\";s:4:\"name\";s:10:\"Bangladesh\";}i:19;a:2:{s:4:\"code\";s:2:\"BE\";s:4:\"name\";s:7:\"Belgium\";}i:20;a:2:{s:4:\"code\";s:2:\"BF\";s:4:\"name\";s:12:\"Burkina Faso\";}i:21;a:2:{s:4:\"code\";s:2:\"BG\";s:4:\"name\";s:8:\"Bulgaria\";}i:22;a:2:{s:4:\"code\";s:2:\"BH\";s:4:\"name\";s:7:\"Bahrain\";}i:23;a:2:{s:4:\"code\";s:2:\"BI\";s:4:\"name\";s:7:\"Burundi\";}i:24;a:2:{s:4:\"code\";s:2:\"BJ\";s:4:\"name\";s:5:\"Benin\";}i:25;a:2:{s:4:\"code\";s:2:\"BL\";s:4:\"name\";s:17:\"Saint Barthélemy\";}i:26;a:2:{s:4:\"code\";s:2:\"BM\";s:4:\"name\";s:7:\"Bermuda\";}i:27;a:2:{s:4:\"code\";s:2:\"BN\";s:4:\"name\";s:17:\"Brunei Darussalam\";}i:28;a:2:{s:4:\"code\";s:2:\"BO\";s:4:\"name\";s:32:\"Bolivia, Plurinational States of\";}i:29;a:2:{s:4:\"code\";s:2:\"BQ\";s:4:\"name\";s:32:\"Bonaire, Sint Eustatius and Saba\";}i:30;a:2:{s:4:\"code\";s:2:\"BR\";s:4:\"name\";s:6:\"Brazil\";}i:31;a:2:{s:4:\"code\";s:2:\"BS\";s:4:\"name\";s:7:\"Bahamas\";}i:32;a:2:{s:4:\"code\";s:2:\"BT\";s:4:\"name\";s:6:\"Bhutan\";}i:33;a:2:{s:4:\"code\";s:2:\"BV\";s:4:\"name\";s:13:\"Bouvet Island\";}i:34;a:2:{s:4:\"code\";s:2:\"BW\";s:4:\"name\";s:8:\"Botswana\";}i:35;a:2:{s:4:\"code\";s:2:\"BY\";s:4:\"name\";s:7:\"Belarus\";}i:36;a:2:{s:4:\"code\";s:2:\"BZ\";s:4:\"name\";s:6:\"Belize\";}i:37;a:2:{s:4:\"code\";s:2:\"CA\";s:4:\"name\";s:6:\"Canada\";}i:38;a:2:{s:4:\"code\";s:2:\"CC\";s:4:\"name\";s:23:\"Cocos (Keeling) Islands\";}i:39;a:2:{s:4:\"code\";s:2:\"CD\";s:4:\"name\";s:37:\"Congo, The Democratic Republic of the\";}i:40;a:2:{s:4:\"code\";s:2:\"CF\";s:4:\"name\";s:24:\"Central African Republic\";}i:41;a:2:{s:4:\"code\";s:2:\"CG\";s:4:\"name\";s:5:\"Congo\";}i:42;a:2:{s:4:\"code\";s:2:\"CH\";s:4:\"name\";s:11:\"Switzerland\";}i:43;a:2:{s:4:\"code\";s:2:\"CI\";s:4:\"name\";s:14:\"Côte d\'Ivoire\";}i:44;a:2:{s:4:\"code\";s:2:\"CK\";s:4:\"name\";s:12:\"Cook Islands\";}i:45;a:2:{s:4:\"code\";s:2:\"CL\";s:4:\"name\";s:5:\"Chile\";}i:46;a:2:{s:4:\"code\";s:2:\"CM\";s:4:\"name\";s:8:\"Cameroon\";}i:47;a:2:{s:4:\"code\";s:2:\"CN\";s:4:\"name\";s:5:\"China\";}i:48;a:2:{s:4:\"code\";s:2:\"CO\";s:4:\"name\";s:8:\"Colombia\";}i:49;a:2:{s:4:\"code\";s:2:\"CR\";s:4:\"name\";s:10:\"Costa Rica\";}i:50;a:2:{s:4:\"code\";s:2:\"CU\";s:4:\"name\";s:4:\"Cuba\";}i:51;a:2:{s:4:\"code\";s:2:\"CV\";s:4:\"name\";s:10:\"Cabo Verde\";}i:52;a:2:{s:4:\"code\";s:2:\"CW\";s:4:\"name\";s:8:\"Curaçao\";}i:53;a:2:{s:4:\"code\";s:2:\"CX\";s:4:\"name\";s:16:\"Christmas Island\";}i:54;a:2:{s:4:\"code\";s:2:\"CY\";s:4:\"name\";s:6:\"Cyprus\";}i:55;a:2:{s:4:\"code\";s:2:\"CZ\";s:4:\"name\";s:7:\"Czechia\";}i:56;a:2:{s:4:\"code\";s:2:\"DE\";s:4:\"name\";s:7:\"Germany\";}i:57;a:2:{s:4:\"code\";s:2:\"DJ\";s:4:\"name\";s:8:\"Djibouti\";}i:58;a:2:{s:4:\"code\";s:2:\"DK\";s:4:\"name\";s:7:\"Denmark\";}i:59;a:2:{s:4:\"code\";s:2:\"DM\";s:4:\"name\";s:8:\"Dominica\";}i:60;a:2:{s:4:\"code\";s:2:\"DO\";s:4:\"name\";s:18:\"Dominican Republic\";}i:61;a:2:{s:4:\"code\";s:2:\"DT\";s:4:\"name\";s:18:\"Disputed Territory\";}i:62;a:2:{s:4:\"code\";s:2:\"DZ\";s:4:\"name\";s:7:\"Algeria\";}i:63;a:2:{s:4:\"code\";s:2:\"EC\";s:4:\"name\";s:7:\"Ecuador\";}i:64;a:2:{s:4:\"code\";s:2:\"EE\";s:4:\"name\";s:7:\"Estonia\";}i:65;a:2:{s:4:\"code\";s:2:\"EG\";s:4:\"name\";s:5:\"Egypt\";}i:66;a:2:{s:4:\"code\";s:2:\"EH\";s:4:\"name\";s:14:\"Western Sahara\";}i:67;a:2:{s:4:\"code\";s:2:\"ER\";s:4:\"name\";s:7:\"Eritrea\";}i:68;a:2:{s:4:\"code\";s:2:\"ES\";s:4:\"name\";s:5:\"Spain\";}i:69;a:2:{s:4:\"code\";s:2:\"ET\";s:4:\"name\";s:8:\"Ethiopia\";}i:70;a:2:{s:4:\"code\";s:2:\"FI\";s:4:\"name\";s:7:\"Finland\";}i:71;a:2:{s:4:\"code\";s:2:\"FJ\";s:4:\"name\";s:4:\"Fiji\";}i:72;a:2:{s:4:\"code\";s:2:\"FK\";s:4:\"name\";s:27:\"Falkland Islands (Malvinas)\";}i:73;a:2:{s:4:\"code\";s:2:\"FM\";s:4:\"name\";s:32:\"Micronesia, Federated States of \";}i:74;a:2:{s:4:\"code\";s:2:\"FO\";s:4:\"name\";s:13:\"Faroe Islands\";}i:75;a:2:{s:4:\"code\";s:2:\"FR\";s:4:\"name\";s:6:\"France\";}i:76;a:2:{s:4:\"code\";s:2:\"GA\";s:4:\"name\";s:5:\"Gabon\";}i:77;a:2:{s:4:\"code\";s:2:\"GB\";s:4:\"name\";s:14:\"United Kingdom\";}i:78;a:2:{s:4:\"code\";s:2:\"GD\";s:4:\"name\";s:7:\"Grenada\";}i:79;a:2:{s:4:\"code\";s:2:\"GE\";s:4:\"name\";s:7:\"Georgia\";}i:80;a:2:{s:4:\"code\";s:2:\"GF\";s:4:\"name\";s:13:\"French Guiana\";}i:81;a:2:{s:4:\"code\";s:2:\"GG\";s:4:\"name\";s:8:\"Guernsey\";}i:82;a:2:{s:4:\"code\";s:2:\"GH\";s:4:\"name\";s:5:\"Ghana\";}i:83;a:2:{s:4:\"code\";s:2:\"GI\";s:4:\"name\";s:9:\"Gibraltar\";}i:84;a:2:{s:4:\"code\";s:2:\"GL\";s:4:\"name\";s:9:\"Greenland\";}i:85;a:2:{s:4:\"code\";s:2:\"GM\";s:4:\"name\";s:6:\"Gambia\";}i:86;a:2:{s:4:\"code\";s:2:\"GN\";s:4:\"name\";s:6:\"Guinea\";}i:87;a:2:{s:4:\"code\";s:2:\"GP\";s:4:\"name\";s:10:\"Guadeloupe\";}i:88;a:2:{s:4:\"code\";s:2:\"GQ\";s:4:\"name\";s:17:\"Equatorial Guinea\";}i:89;a:2:{s:4:\"code\";s:2:\"GR\";s:4:\"name\";s:6:\"Greece\";}i:90;a:2:{s:4:\"code\";s:2:\"GS\";s:4:\"name\";s:44:\"South Georgia and the South Sandwich Islands\";}i:91;a:2:{s:4:\"code\";s:2:\"GT\";s:4:\"name\";s:9:\"Guatemala\";}i:92;a:2:{s:4:\"code\";s:2:\"GU\";s:4:\"name\";s:4:\"Guam\";}i:93;a:2:{s:4:\"code\";s:2:\"GW\";s:4:\"name\";s:13:\"Guinea-Bissau\";}i:94;a:2:{s:4:\"code\";s:2:\"GY\";s:4:\"name\";s:6:\"Guyana\";}i:95;a:2:{s:4:\"code\";s:2:\"HK\";s:4:\"name\";s:9:\"Hong Kong\";}i:96;a:2:{s:4:\"code\";s:2:\"HM\";s:4:\"name\";s:33:\"Heard Island and McDonald Islands\";}i:97;a:2:{s:4:\"code\";s:2:\"HN\";s:4:\"name\";s:8:\"Honduras\";}i:98;a:2:{s:4:\"code\";s:2:\"HR\";s:4:\"name\";s:7:\"Croatia\";}i:99;a:2:{s:4:\"code\";s:2:\"HT\";s:4:\"name\";s:5:\"Haiti\";}i:100;a:2:{s:4:\"code\";s:2:\"HU\";s:4:\"name\";s:7:\"Hungary\";}i:101;a:2:{s:4:\"code\";s:2:\"ID\";s:4:\"name\";s:9:\"Indonesia\";}i:102;a:2:{s:4:\"code\";s:2:\"IE\";s:4:\"name\";s:7:\"Ireland\";}i:103;a:2:{s:4:\"code\";s:2:\"IL\";s:4:\"name\";s:6:\"Israel\";}i:104;a:2:{s:4:\"code\";s:2:\"IM\";s:4:\"name\";s:11:\"Isle of Man\";}i:105;a:2:{s:4:\"code\";s:2:\"IN\";s:4:\"name\";s:5:\"India\";}i:106;a:2:{s:4:\"code\";s:2:\"IO\";s:4:\"name\";s:30:\"British Indian Ocean Territory\";}i:107;a:2:{s:4:\"code\";s:2:\"IQ\";s:4:\"name\";s:4:\"Iraq\";}i:108;a:2:{s:4:\"code\";s:2:\"IR\";s:4:\"name\";s:25:\"Iran, Islamic Republic of\";}i:109;a:2:{s:4:\"code\";s:2:\"IS\";s:4:\"name\";s:7:\"Iceland\";}i:110;a:2:{s:4:\"code\";s:2:\"IT\";s:4:\"name\";s:5:\"Italy\";}i:111;a:2:{s:4:\"code\";s:2:\"JE\";s:4:\"name\";s:6:\"Jersey\";}i:112;a:2:{s:4:\"code\";s:2:\"JM\";s:4:\"name\";s:7:\"Jamaica\";}i:113;a:2:{s:4:\"code\";s:2:\"JO\";s:4:\"name\";s:6:\"Jordan\";}i:114;a:2:{s:4:\"code\";s:2:\"JP\";s:4:\"name\";s:5:\"Japan\";}i:115;a:2:{s:4:\"code\";s:2:\"KE\";s:4:\"name\";s:5:\"Kenya\";}i:116;a:2:{s:4:\"code\";s:2:\"KG\";s:4:\"name\";s:10:\"Kyrgyzstan\";}i:117;a:2:{s:4:\"code\";s:2:\"KH\";s:4:\"name\";s:8:\"Cambodia\";}i:118;a:2:{s:4:\"code\";s:2:\"KI\";s:4:\"name\";s:8:\"Kiribati\";}i:119;a:2:{s:4:\"code\";s:2:\"KM\";s:4:\"name\";s:7:\"Comoros\";}i:120;a:2:{s:4:\"code\";s:2:\"KN\";s:4:\"name\";s:21:\"Saint Kitts and Nevis\";}i:121;a:2:{s:4:\"code\";s:2:\"KP\";s:4:\"name\";s:38:\"Korea, Democratic People\'s Republic of\";}i:122;a:2:{s:4:\"code\";s:2:\"KR\";s:4:\"name\";s:18:\"Korea, Republic of\";}i:123;a:2:{s:4:\"code\";s:2:\"KW\";s:4:\"name\";s:6:\"Kuwait\";}i:124;a:2:{s:4:\"code\";s:2:\"KY\";s:4:\"name\";s:14:\"Cayman Islands\";}i:125;a:2:{s:4:\"code\";s:2:\"KZ\";s:4:\"name\";s:10:\"Kazakhstan\";}i:126;a:2:{s:4:\"code\";s:2:\"LA\";s:4:\"name\";s:32:\"Lao People\'s Democratic Republic\";}i:127;a:2:{s:4:\"code\";s:2:\"LB\";s:4:\"name\";s:7:\"Lebanon\";}i:128;a:2:{s:4:\"code\";s:2:\"LC\";s:4:\"name\";s:11:\"Saint Lucia\";}i:129;a:2:{s:4:\"code\";s:2:\"LI\";s:4:\"name\";s:13:\"Liechtenstein\";}i:130;a:2:{s:4:\"code\";s:2:\"LK\";s:4:\"name\";s:9:\"Sri Lanka\";}i:131;a:2:{s:4:\"code\";s:2:\"LR\";s:4:\"name\";s:7:\"Liberia\";}i:132;a:2:{s:4:\"code\";s:2:\"LS\";s:4:\"name\";s:7:\"Lesotho\";}i:133;a:2:{s:4:\"code\";s:2:\"LT\";s:4:\"name\";s:9:\"Lithuania\";}i:134;a:2:{s:4:\"code\";s:2:\"LU\";s:4:\"name\";s:10:\"Luxembourg\";}i:135;a:2:{s:4:\"code\";s:2:\"LV\";s:4:\"name\";s:6:\"Latvia\";}i:136;a:2:{s:4:\"code\";s:2:\"LY\";s:4:\"name\";s:5:\"Libya\";}i:137;a:2:{s:4:\"code\";s:2:\"MA\";s:4:\"name\";s:7:\"Morocco\";}i:138;a:2:{s:4:\"code\";s:2:\"MC\";s:4:\"name\";s:6:\"Monaco\";}i:139;a:2:{s:4:\"code\";s:2:\"MD\";s:4:\"name\";s:7:\"Moldova\";}i:140;a:2:{s:4:\"code\";s:2:\"ME\";s:4:\"name\";s:10:\"Montenegro\";}i:141;a:2:{s:4:\"code\";s:2:\"MF\";s:4:\"name\";s:26:\"Saint Martin (French part)\";}i:142;a:2:{s:4:\"code\";s:2:\"MG\";s:4:\"name\";s:10:\"Madagascar\";}i:143;a:2:{s:4:\"code\";s:2:\"MH\";s:4:\"name\";s:16:\"Marshall Islands\";}i:144;a:2:{s:4:\"code\";s:2:\"MK\";s:4:\"name\";s:15:\"North Macedonia\";}i:145;a:2:{s:4:\"code\";s:2:\"ML\";s:4:\"name\";s:4:\"Mali\";}i:146;a:2:{s:4:\"code\";s:2:\"MM\";s:4:\"name\";s:7:\"Myanmar\";}i:147;a:2:{s:4:\"code\";s:2:\"MN\";s:4:\"name\";s:8:\"Mongolia\";}i:148;a:2:{s:4:\"code\";s:2:\"MO\";s:4:\"name\";s:5:\"Macao\";}i:149;a:2:{s:4:\"code\";s:2:\"MP\";s:4:\"name\";s:24:\"Northern Mariana Islands\";}i:150;a:2:{s:4:\"code\";s:2:\"MQ\";s:4:\"name\";s:10:\"Martinique\";}i:151;a:2:{s:4:\"code\";s:2:\"MR\";s:4:\"name\";s:10:\"Mauritania\";}i:152;a:2:{s:4:\"code\";s:2:\"MS\";s:4:\"name\";s:10:\"Montserrat\";}i:153;a:2:{s:4:\"code\";s:2:\"MT\";s:4:\"name\";s:5:\"Malta\";}i:154;a:2:{s:4:\"code\";s:2:\"MU\";s:4:\"name\";s:9:\"Mauritius\";}i:155;a:2:{s:4:\"code\";s:2:\"MV\";s:4:\"name\";s:8:\"Maldives\";}i:156;a:2:{s:4:\"code\";s:2:\"MW\";s:4:\"name\";s:6:\"Malawi\";}i:157;a:2:{s:4:\"code\";s:2:\"MX\";s:4:\"name\";s:6:\"Mexico\";}i:158;a:2:{s:4:\"code\";s:2:\"MY\";s:4:\"name\";s:8:\"Malaysia\";}i:159;a:2:{s:4:\"code\";s:2:\"MZ\";s:4:\"name\";s:10:\"Mozambique\";}i:160;a:2:{s:4:\"code\";s:2:\"NA\";s:4:\"name\";s:7:\"Namibia\";}i:161;a:2:{s:4:\"code\";s:2:\"NC\";s:4:\"name\";s:13:\"New Caledonia\";}i:162;a:2:{s:4:\"code\";s:2:\"NE\";s:4:\"name\";s:5:\"Niger\";}i:163;a:2:{s:4:\"code\";s:2:\"NF\";s:4:\"name\";s:14:\"Norfolk Island\";}i:164;a:2:{s:4:\"code\";s:2:\"NG\";s:4:\"name\";s:7:\"Nigeria\";}i:165;a:2:{s:4:\"code\";s:2:\"NI\";s:4:\"name\";s:9:\"Nicaragua\";}i:166;a:2:{s:4:\"code\";s:2:\"NL\";s:4:\"name\";s:11:\"Netherlands\";}i:167;a:2:{s:4:\"code\";s:2:\"NO\";s:4:\"name\";s:6:\"Norway\";}i:168;a:2:{s:4:\"code\";s:2:\"NP\";s:4:\"name\";s:5:\"Nepal\";}i:169;a:2:{s:4:\"code\";s:2:\"NR\";s:4:\"name\";s:5:\"Nauru\";}i:170;a:2:{s:4:\"code\";s:2:\"NU\";s:4:\"name\";s:4:\"Niue\";}i:171;a:2:{s:4:\"code\";s:2:\"NZ\";s:4:\"name\";s:11:\"New Zealand\";}i:172;a:2:{s:4:\"code\";s:2:\"OM\";s:4:\"name\";s:4:\"Oman\";}i:173;a:2:{s:4:\"code\";s:2:\"PA\";s:4:\"name\";s:6:\"Panama\";}i:174;a:2:{s:4:\"code\";s:2:\"PE\";s:4:\"name\";s:4:\"Peru\";}i:175;a:2:{s:4:\"code\";s:2:\"PF\";s:4:\"name\";s:16:\"French Polynesia\";}i:176;a:2:{s:4:\"code\";s:2:\"PG\";s:4:\"name\";s:16:\"Papua New Guinea\";}i:177;a:2:{s:4:\"code\";s:2:\"PH\";s:4:\"name\";s:11:\"Philippines\";}i:178;a:2:{s:4:\"code\";s:2:\"PK\";s:4:\"name\";s:8:\"Pakistan\";}i:179;a:2:{s:4:\"code\";s:2:\"PL\";s:4:\"name\";s:6:\"Poland\";}i:180;a:2:{s:4:\"code\";s:2:\"PM\";s:4:\"name\";s:25:\"Saint Pierre and Miquelon\";}i:181;a:2:{s:4:\"code\";s:2:\"PN\";s:4:\"name\";s:8:\"Pitcairn\";}i:182;a:2:{s:4:\"code\";s:2:\"PR\";s:4:\"name\";s:11:\"Puerto Rico\";}i:183;a:2:{s:4:\"code\";s:2:\"PS\";s:4:\"name\";s:19:\"Palestine, State of\";}i:184;a:2:{s:4:\"code\";s:2:\"PT\";s:4:\"name\";s:8:\"Portugal\";}i:185;a:2:{s:4:\"code\";s:2:\"PW\";s:4:\"name\";s:5:\"Palau\";}i:186;a:2:{s:4:\"code\";s:2:\"PY\";s:4:\"name\";s:8:\"Paraguay\";}i:187;a:2:{s:4:\"code\";s:2:\"QA\";s:4:\"name\";s:5:\"Qatar\";}i:188;a:2:{s:4:\"code\";s:2:\"RE\";s:4:\"name\";s:8:\"Réunion\";}i:189;a:2:{s:4:\"code\";s:2:\"RO\";s:4:\"name\";s:7:\"Romania\";}i:190;a:2:{s:4:\"code\";s:2:\"RS\";s:4:\"name\";s:6:\"Serbia\";}i:191;a:2:{s:4:\"code\";s:2:\"RU\";s:4:\"name\";s:18:\"Russian Federation\";}i:192;a:2:{s:4:\"code\";s:2:\"RW\";s:4:\"name\";s:6:\"Rwanda\";}i:193;a:2:{s:4:\"code\";s:2:\"SA\";s:4:\"name\";s:12:\"Saudi Arabia\";}i:194;a:2:{s:4:\"code\";s:2:\"SB\";s:4:\"name\";s:15:\"Solomon Islands\";}i:195;a:2:{s:4:\"code\";s:2:\"SC\";s:4:\"name\";s:10:\"Seychelles\";}i:196;a:2:{s:4:\"code\";s:2:\"SD\";s:4:\"name\";s:5:\"Sudan\";}i:197;a:2:{s:4:\"code\";s:2:\"SE\";s:4:\"name\";s:6:\"Sweden\";}i:198;a:2:{s:4:\"code\";s:2:\"SG\";s:4:\"name\";s:9:\"Singapore\";}i:199;a:2:{s:4:\"code\";s:2:\"SH\";s:4:\"name\";s:44:\"Saint Helena, Ascension and Tristan da Cunha\";}i:200;a:2:{s:4:\"code\";s:2:\"SI\";s:4:\"name\";s:8:\"Slovenia\";}i:201;a:2:{s:4:\"code\";s:2:\"SJ\";s:4:\"name\";s:22:\"Svalbard and Jan Mayen\";}i:202;a:2:{s:4:\"code\";s:2:\"SK\";s:4:\"name\";s:8:\"Slovakia\";}i:203;a:2:{s:4:\"code\";s:2:\"SL\";s:4:\"name\";s:12:\"Sierra Leone\";}i:204;a:2:{s:4:\"code\";s:2:\"SM\";s:4:\"name\";s:10:\"San Marino\";}i:205;a:2:{s:4:\"code\";s:2:\"SN\";s:4:\"name\";s:7:\"Senegal\";}i:206;a:2:{s:4:\"code\";s:2:\"SO\";s:4:\"name\";s:7:\"Somalia\";}i:207;a:2:{s:4:\"code\";s:2:\"SR\";s:4:\"name\";s:8:\"Suriname\";}i:208;a:2:{s:4:\"code\";s:2:\"SS\";s:4:\"name\";s:11:\"South Sudan\";}i:209;a:2:{s:4:\"code\";s:2:\"ST\";s:4:\"name\";s:21:\"Sao Tome and Principe\";}i:210;a:2:{s:4:\"code\";s:2:\"SV\";s:4:\"name\";s:11:\"El Salvador\";}i:211;a:2:{s:4:\"code\";s:2:\"SX\";s:4:\"name\";s:25:\"Sint Maarten (Dutch part)\";}i:212;a:2:{s:4:\"code\";s:2:\"SY\";s:4:\"name\";s:20:\"Syrian Arab Republic\";}i:213;a:2:{s:4:\"code\";s:2:\"SZ\";s:4:\"name\";s:8:\"Eswatini\";}i:214;a:2:{s:4:\"code\";s:2:\"TC\";s:4:\"name\";s:24:\"Turks and Caicos Islands\";}i:215;a:2:{s:4:\"code\";s:2:\"TD\";s:4:\"name\";s:4:\"Chad\";}i:216;a:2:{s:4:\"code\";s:2:\"TF\";s:4:\"name\";s:27:\"French Southern Territories\";}i:217;a:2:{s:4:\"code\";s:2:\"TG\";s:4:\"name\";s:4:\"Togo\";}i:218;a:2:{s:4:\"code\";s:2:\"TH\";s:4:\"name\";s:8:\"Thailand\";}i:219;a:2:{s:4:\"code\";s:2:\"TJ\";s:4:\"name\";s:10:\"Tajikistan\";}i:220;a:2:{s:4:\"code\";s:2:\"TK\";s:4:\"name\";s:7:\"Tokelau\";}i:221;a:2:{s:4:\"code\";s:2:\"TL\";s:4:\"name\";s:11:\"Timor-Leste\";}i:222;a:2:{s:4:\"code\";s:2:\"TM\";s:4:\"name\";s:12:\"Turkmenistan\";}i:223;a:2:{s:4:\"code\";s:2:\"TN\";s:4:\"name\";s:7:\"Tunisia\";}i:224;a:2:{s:4:\"code\";s:2:\"TO\";s:4:\"name\";s:5:\"Tonga\";}i:225;a:2:{s:4:\"code\";s:2:\"TR\";s:4:\"name\";s:8:\"Türkiye\";}i:226;a:2:{s:4:\"code\";s:2:\"TT\";s:4:\"name\";s:19:\"Trinidad and Tobago\";}i:227;a:2:{s:4:\"code\";s:2:\"TV\";s:4:\"name\";s:6:\"Tuvalu\";}i:228;a:2:{s:4:\"code\";s:2:\"TW\";s:4:\"name\";s:25:\"Taiwan, Province of China\";}i:229;a:2:{s:4:\"code\";s:2:\"TZ\";s:4:\"name\";s:28:\"Tanzania, United Republic of\";}i:230;a:2:{s:4:\"code\";s:2:\"UA\";s:4:\"name\";s:7:\"Ukraine\";}i:231;a:2:{s:4:\"code\";s:2:\"UG\";s:4:\"name\";s:6:\"Uganda\";}i:232;a:2:{s:4:\"code\";s:2:\"UM\";s:4:\"name\";s:36:\"United States Minor Outlying Islands\";}i:233;a:2:{s:4:\"code\";s:2:\"US\";s:4:\"name\";s:13:\"United States\";}i:234;a:2:{s:4:\"code\";s:2:\"UY\";s:4:\"name\";s:7:\"Uruguay\";}i:235;a:2:{s:4:\"code\";s:2:\"UZ\";s:4:\"name\";s:10:\"Uzbekistan\";}i:236;a:2:{s:4:\"code\";s:2:\"VA\";s:4:\"name\";s:29:\"Holy See (Vatican City State)\";}i:237;a:2:{s:4:\"code\";s:2:\"VC\";s:4:\"name\";s:32:\"Saint Vincent and the Grenadines\";}i:238;a:2:{s:4:\"code\";s:2:\"VE\";s:4:\"name\";s:33:\"Venezuela, Bolivarian Republic of\";}i:239;a:2:{s:4:\"code\";s:2:\"VG\";s:4:\"name\";s:23:\"Virgin Islands, British\";}i:240;a:2:{s:4:\"code\";s:2:\"VI\";s:4:\"name\";s:20:\"Virgin Islands, U.S.\";}i:241;a:2:{s:4:\"code\";s:2:\"VN\";s:4:\"name\";s:8:\"Viet Nam\";}i:242;a:2:{s:4:\"code\";s:2:\"VU\";s:4:\"name\";s:7:\"Vanuatu\";}i:243;a:2:{s:4:\"code\";s:2:\"WF\";s:4:\"name\";s:17:\"Wallis and Futuna\";}i:244;a:2:{s:4:\"code\";s:2:\"WS\";s:4:\"name\";s:5:\"Samoa\";}i:245;a:2:{s:4:\"code\";s:2:\"YE\";s:4:\"name\";s:5:\"Yemen\";}i:246;a:2:{s:4:\"code\";s:2:\"YT\";s:4:\"name\";s:7:\"Mayotte\";}i:247;a:2:{s:4:\"code\";s:2:\"ZA\";s:4:\"name\";s:12:\"South Africa\";}i:248;a:2:{s:4:\"code\";s:2:\"ZM\";s:4:\"name\";s:6:\"Zambia\";}i:249;a:2:{s:4:\"code\";s:2:\"ZW\";s:4:\"name\";s:8:\"Zimbabwe\";}}',1771883423),
('iucn-red-list-cache-iucn.statistics','a:3:{s:11:\"api_version\";s:2:\"v4\";s:16:\"red_list_version\";s:6:\"2025-2\";s:13:\"species_count\";i:172620;}',1771966224),
('iucn-red-list-cache-iucn.system.terrestrial.page.1','a:2:{s:11:\"assessments\";a:0:{}s:10:\"pagination\";a:4:{s:5:\"total\";i:0;s:8:\"per_page\";i:100;s:12:\"current_page\";i:1;s:11:\"total_pages\";i:1;}}',1771883425),
('iucn-red-list-cache-iucn.systems','a:3:{i:0;a:2:{s:4:\"code\";s:1:\"0\";s:4:\"name\";s:11:\"Terrestrial\";}i:1;a:2:{s:4:\"code\";s:1:\"1\";s:4:\"name\";s:27:\"Freshwater (=Inland waters)\";}i:2;a:2:{s:4:\"code\";s:1:\"2\";s:4:\"name\";s:6:\"Marine\";}}',1771883423),
('iucn-red-list-cache-iucn.taxon.22823','a:3:{s:6:\"sis_id\";i:22823;s:5:\"taxon\";a:21:{s:6:\"sis_id\";i:22823;s:15:\"scientific_name\";s:15:\"Ursus maritimus\";s:12:\"species_taxa\";a:0:{}s:18:\"subpopulation_taxa\";a:0:{}s:14:\"infrarank_taxa\";a:0:{}s:12:\"kingdom_name\";s:8:\"ANIMALIA\";s:11:\"phylum_name\";s:8:\"CHORDATA\";s:10:\"class_name\";s:8:\"MAMMALIA\";s:10:\"order_name\";s:9:\"CARNIVORA\";s:11:\"family_name\";s:7:\"URSIDAE\";s:10:\"genus_name\";s:5:\"Ursus\";s:12:\"species_name\";s:9:\"maritimus\";s:18:\"subpopulation_name\";N;s:10:\"infra_name\";N;s:9:\"authority\";s:12:\"Phipps, 1774\";s:7:\"species\";b:1;s:13:\"subpopulation\";b:0;s:9:\"infrarank\";b:0;s:10:\"ssc_groups\";a:1:{i:0;a:3:{s:4:\"name\";s:36:\"IUCN SSC Polar Bear Specialist Group\";s:3:\"url\";s:25:\"http://pbsg.npolar.no/en/\";s:11:\"description\";s:172:\"Co-Chairs: Dag Vongraven (email: dag.vongraven@npolar.no) and Nicholas Lunn (email: nick.lunn@canada.ca)\nRed List Authority Focal Point: Eric Regehr (email: eregehr@uw.edu)\";}}s:12:\"common_names\";a:6:{i:0;a:3:{s:4:\"main\";b:0;s:4:\"name\";s:11:\"Bely Medved\";s:8:\"language\";s:3:\"rus\";}i:1;a:3:{s:4:\"main\";b:0;s:4:\"name\";s:8:\"Isbjørn\";s:8:\"language\";s:3:\"nor\";}i:2;a:3:{s:4:\"main\";b:0;s:4:\"name\";s:9:\"Oso Polar\";s:8:\"language\";s:3:\"spa\";}i:3;a:3:{s:4:\"main\";b:0;s:4:\"name\";s:10:\"Ours blanc\";s:8:\"language\";s:3:\"fre\";}i:4;a:3:{s:4:\"main\";b:0;s:4:\"name\";s:12:\"Ours polaire\";s:8:\"language\";s:3:\"fre\";}i:5;a:3:{s:4:\"main\";b:1;s:4:\"name\";s:10:\"Polar Bear\";s:8:\"language\";s:3:\"eng\";}}s:8:\"synonyms\";a:1:{i:0;a:9:{s:4:\"name\";s:35:\"Thalarctos maritimus (Phipps, 1774)\";s:6:\"status\";s:8:\"ACCEPTED\";s:10:\"genus_name\";s:10:\"Thalarctos\";s:12:\"species_name\";s:9:\"maritimus\";s:14:\"species_author\";s:14:\"(Phipps, 1774)\";s:16:\"infrarank_author\";N;s:18:\"subpopulation_name\";N;s:10:\"infra_type\";N;s:10:\"infra_name\";N;}}}s:11:\"assessments\";a:12:{i:0;a:10:{s:14:\"year_published\";s:4:\"2025\";s:6:\"latest\";b:1;s:16:\"possibly_extinct\";b:0;s:28:\"possibly_extinct_in_the_wild\";b:0;s:12:\"sis_taxon_id\";i:22823;s:3:\"url\";s:51:\"https://www.iucnredlist.org/species/22823/217912462\";s:21:\"taxon_scientific_name\";s:15:\"Ursus maritimus\";s:22:\"red_list_category_code\";s:2:\"VU\";s:13:\"assessment_id\";i:217912462;s:6:\"scopes\";a:1:{i:0;a:2:{s:11:\"description\";a:1:{s:2:\"en\";s:6:\"Europe\";}s:4:\"code\";s:1:\"2\";}}}i:1;a:10:{s:14:\"year_published\";s:4:\"2015\";s:6:\"latest\";b:1;s:16:\"possibly_extinct\";b:0;s:28:\"possibly_extinct_in_the_wild\";b:0;s:12:\"sis_taxon_id\";i:22823;s:3:\"url\";s:50:\"https://www.iucnredlist.org/species/22823/14871490\";s:21:\"taxon_scientific_name\";s:15:\"Ursus maritimus\";s:22:\"red_list_category_code\";s:2:\"VU\";s:13:\"assessment_id\";i:14871490;s:6:\"scopes\";a:1:{i:0;a:2:{s:11:\"description\";a:1:{s:2:\"en\";s:6:\"Global\";}s:4:\"code\";s:1:\"1\";}}}i:2;a:10:{s:14:\"year_published\";s:4:\"2008\";s:6:\"latest\";b:0;s:16:\"possibly_extinct\";b:0;s:28:\"possibly_extinct_in_the_wild\";b:0;s:12:\"sis_taxon_id\";i:22823;s:3:\"url\";s:49:\"https://www.iucnredlist.org/species/22823/9391171\";s:21:\"taxon_scientific_name\";s:15:\"Ursus maritimus\";s:22:\"red_list_category_code\";s:2:\"VU\";s:13:\"assessment_id\";i:9391171;s:6:\"scopes\";a:1:{i:0;a:2:{s:11:\"description\";a:1:{s:2:\"en\";s:6:\"Global\";}s:4:\"code\";s:1:\"1\";}}}i:3;a:10:{s:14:\"year_published\";s:4:\"2007\";s:6:\"latest\";b:0;s:16:\"possibly_extinct\";b:0;s:28:\"possibly_extinct_in_the_wild\";b:0;s:12:\"sis_taxon_id\";i:22823;s:3:\"url\";s:49:\"https://www.iucnredlist.org/species/22823/9390963\";s:21:\"taxon_scientific_name\";s:15:\"Ursus maritimus\";s:22:\"red_list_category_code\";s:2:\"VU\";s:13:\"assessment_id\";i:9390963;s:6:\"scopes\";a:1:{i:0;a:2:{s:11:\"description\";a:1:{s:2:\"en\";s:6:\"Europe\";}s:4:\"code\";s:1:\"2\";}}}i:4;a:10:{s:14:\"year_published\";s:4:\"2006\";s:6:\"latest\";b:0;s:16:\"possibly_extinct\";b:0;s:28:\"possibly_extinct_in_the_wild\";b:0;s:12:\"sis_taxon_id\";i:22823;s:3:\"url\";s:49:\"https://www.iucnredlist.org/species/22823/9390655\";s:21:\"taxon_scientific_name\";s:15:\"Ursus maritimus\";s:22:\"red_list_category_code\";s:2:\"VU\";s:13:\"assessment_id\";i:9390655;s:6:\"scopes\";a:1:{i:0;a:2:{s:11:\"description\";a:1:{s:2:\"en\";s:6:\"Global\";}s:4:\"code\";s:1:\"1\";}}}i:5;a:10:{s:14:\"year_published\";s:4:\"1996\";s:6:\"latest\";b:0;s:16:\"possibly_extinct\";b:0;s:28:\"possibly_extinct_in_the_wild\";b:0;s:12:\"sis_taxon_id\";i:22823;s:3:\"url\";s:49:\"https://www.iucnredlist.org/species/22823/9390941\";s:21:\"taxon_scientific_name\";s:15:\"Ursus maritimus\";s:22:\"red_list_category_code\";s:5:\"LR/cd\";s:13:\"assessment_id\";i:9390941;s:6:\"scopes\";a:1:{i:0;a:2:{s:11:\"description\";a:1:{s:2:\"en\";s:6:\"Global\";}s:4:\"code\";s:1:\"1\";}}}i:6;a:10:{s:14:\"year_published\";s:4:\"1994\";s:6:\"latest\";b:0;s:16:\"possibly_extinct\";b:0;s:28:\"possibly_extinct_in_the_wild\";b:0;s:12:\"sis_taxon_id\";i:22823;s:3:\"url\";s:49:\"https://www.iucnredlist.org/species/22823/9391570\";s:21:\"taxon_scientific_name\";s:15:\"Ursus maritimus\";s:22:\"red_list_category_code\";s:1:\"V\";s:13:\"assessment_id\";i:9391570;s:6:\"scopes\";a:1:{i:0;a:2:{s:11:\"description\";a:1:{s:2:\"en\";s:6:\"Global\";}s:4:\"code\";s:1:\"1\";}}}i:7;a:10:{s:14:\"year_published\";s:4:\"1990\";s:6:\"latest\";b:0;s:16:\"possibly_extinct\";b:0;s:28:\"possibly_extinct_in_the_wild\";b:0;s:12:\"sis_taxon_id\";i:22823;s:3:\"url\";s:49:\"https://www.iucnredlist.org/species/22823/9391551\";s:21:\"taxon_scientific_name\";s:15:\"Ursus maritimus\";s:22:\"red_list_category_code\";s:1:\"V\";s:13:\"assessment_id\";i:9391551;s:6:\"scopes\";a:1:{i:0;a:2:{s:11:\"description\";a:1:{s:2:\"en\";s:6:\"Global\";}s:4:\"code\";s:1:\"1\";}}}i:8;a:10:{s:14:\"year_published\";s:4:\"1988\";s:6:\"latest\";b:0;s:16:\"possibly_extinct\";b:0;s:28:\"possibly_extinct_in_the_wild\";b:0;s:12:\"sis_taxon_id\";i:22823;s:3:\"url\";s:49:\"https://www.iucnredlist.org/species/22823/9391493\";s:21:\"taxon_scientific_name\";s:15:\"Ursus maritimus\";s:22:\"red_list_category_code\";s:1:\"V\";s:13:\"assessment_id\";i:9391493;s:6:\"scopes\";a:1:{i:0;a:2:{s:11:\"description\";a:1:{s:2:\"en\";s:6:\"Global\";}s:4:\"code\";s:1:\"1\";}}}i:9;a:10:{s:14:\"year_published\";s:4:\"1986\";s:6:\"latest\";b:0;s:16:\"possibly_extinct\";b:0;s:28:\"possibly_extinct_in_the_wild\";b:0;s:12:\"sis_taxon_id\";i:22823;s:3:\"url\";s:49:\"https://www.iucnredlist.org/species/22823/9391474\";s:21:\"taxon_scientific_name\";s:15:\"Ursus maritimus\";s:22:\"red_list_category_code\";s:1:\"V\";s:13:\"assessment_id\";i:9391474;s:6:\"scopes\";a:1:{i:0;a:2:{s:11:\"description\";a:1:{s:2:\"en\";s:6:\"Global\";}s:4:\"code\";s:1:\"1\";}}}i:10;a:10:{s:14:\"year_published\";s:4:\"1982\";s:6:\"latest\";b:0;s:16:\"possibly_extinct\";b:0;s:28:\"possibly_extinct_in_the_wild\";b:0;s:12:\"sis_taxon_id\";i:22823;s:3:\"url\";s:49:\"https://www.iucnredlist.org/species/22823/9391532\";s:21:\"taxon_scientific_name\";s:15:\"Ursus maritimus\";s:22:\"red_list_category_code\";s:1:\"V\";s:13:\"assessment_id\";i:9391532;s:6:\"scopes\";a:1:{i:0;a:2:{s:11:\"description\";a:1:{s:2:\"en\";s:6:\"Global\";}s:4:\"code\";s:1:\"1\";}}}i:11;a:10:{s:14:\"year_published\";s:4:\"1965\";s:6:\"latest\";b:0;s:16:\"possibly_extinct\";b:0;s:28:\"possibly_extinct_in_the_wild\";b:0;s:12:\"sis_taxon_id\";i:22823;s:3:\"url\";s:49:\"https://www.iucnredlist.org/species/22823/9391512\";s:21:\"taxon_scientific_name\";s:15:\"Ursus maritimus\";s:22:\"red_list_category_code\";s:3:\"N/A\";s:13:\"assessment_id\";i:9391512;s:6:\"scopes\";a:1:{i:0;a:2:{s:11:\"description\";a:1:{s:2:\"en\";s:6:\"Global\";}s:4:\"code\";s:1:\"1\";}}}}}',1771880125);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `favorites` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `taxon_id` bigint(20) unsigned NOT NULL,
  `scientific_name` varchar(255) NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `favorites_taxon_id_unique` (`taxon_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favorites`
--

LOCK TABLES `favorites` WRITE;
/*!40000 ALTER TABLE `favorites` DISABLE KEYS */;
INSERT INTO `favorites` VALUES
(5,10041,'Heosemys annandalii','2026-02-23 20:49:23'),
(6,10267,'Hungerfordia pelewensis','2026-02-23 20:49:23'),
(7,10803,'Iguanognathus werneri','2026-02-23 20:49:24'),
(8,10824,'Indotestudo elongata','2026-02-23 20:49:24'),
(9,10825,'Indotestudo forstenii','2026-02-23 20:49:25'),
(10,1086,'Amblyrhynchus cristatus','2026-02-23 20:49:27');
/*!40000 ALTER TABLE `favorites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2026_02_22_201848_create_favorites_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES
('5Gb8H22b0IHtE8usYjoy2KN3acssZlhR7zhGzRYD',NULL,'172.19.0.2','Mozilla/5.0 (X11; Linux x86_64; rv:147.0) Gecko/20100101 Firefox/147.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSm9CU3pEblFrcXdGY3FwalBiTDVZU1lVSFpNRDlQRUZaaWF4SVFNeSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTQ6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvYXNzZXNzbWVudHMvY291bnRyeS9JVCI7czo1OiJyb3V0ZSI7czoxMToiYXNzZXNzbWVudHMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1771866088),
('5xVpOLKgCCJAsrt49C6o7YlOVasceQxwFwU9bjtG',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiMW55aWt4bXlBRk5temUxOHlVSHhsSFpmNVJEQ0FRN1dCUVRhRDRBUCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDU6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvc3BlY2llcy8yMjgyMyI7czo1OiJyb3V0ZSI7czoxNDoic3BlY2llcy5kZXRhaWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1771866055),
('7BkDxasyUGxMlSPs2Ye0a1o2xpDTxfz520b9Km8d',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoicDdVZEc1R0UyUDlRVlgwM2NnSkFEWVJ2azhiOGhnN09USG5CNnNkMSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771865466),
('a4IGJtTYP8y1wBwefTT8xybYXflXchdlnYV9UaUD',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYnFHbzRLMlI1RXBSU1RpbGo0OHFXNWJ2cDNWTThiSFFEUEVnY0lCMiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvZmF2b3JpdGVzIjtzOjU6InJvdXRlIjtzOjk6ImZhdm9yaXRlcyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771879521),
('B09hsjXDBLJrbxKLMPo2bGX7UHleEsLZOtf5hnmo',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYWxYelRMNkZad1JiaVBoSERDR2dhOTljVkZQb09KSllBNFpPYW1VaCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771865781),
('bgMd5PVUIuQjVI0YYtGaHiW28eCXbyd3xeUy5mEZ',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoieml4aE5hU2ZLYUo3VURhRjF1UGtJcXdIWEdaa2VRQWZZaHU2VVNrcyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NjI6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvYXNzZXNzbWVudHMvc3lzdGVtL3RlcnJlc3RyaWFsIjtzOjU6InJvdXRlIjtzOjExOiJhc3Nlc3NtZW50cyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771879523),
('c6M5UMm7qk42fsrNFnWTBosDsPWWf8761gcL65mw',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWXp0a3NpVDRNZzJEbEJlMWZnRnlMaW1SYUt4RFZPRllPRXhnNmEwcCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NjI6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvYXNzZXNzbWVudHMvc3lzdGVtL3RlcnJlc3RyaWFsIjtzOjU6InJvdXRlIjtzOjExOiJhc3Nlc3NtZW50cyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771879758),
('CNnwq407sounO6S6k4p9SpuQy6sTo7tVtT95RgqX',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ1lGZDdKQU1RWmVTajg4YlQ0a2pvcGFrVUJtbVdubmtyRnkxOEhXMCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NjI6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvYXNzZXNzbWVudHMvc3lzdGVtL3RlcnJlc3RyaWFsIjtzOjU6InJvdXRlIjtzOjExOiJhc3Nlc3NtZW50cyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771866819),
('EBAjveXizbklnrxITSTeNGDENvxJuxPPt5UOe2f8',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWk9kNkpEVjVXc0lLNzNTdk82TGJOYnN1SEx3UFd2RGpic1VSeTNRQyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771864397),
('eXUylASf8UhsyeU99Iy9xv1kzH9GitbMEdSOACEB',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUGxBZVhxd1ROZFRvWGpjQkNGT3hnamtzMFJQTld6QWxOWm42NUpmQSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTI6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvYXNzZXNzbWVudC8xNzIwNDYyNTQiO3M6NToicm91dGUiO3M6MTc6ImFzc2Vzc21lbnQuZGV0YWlsIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771866818),
('fjeEIQNzYy1al7k4HET3bVaPIahBW3W3PdIXCSz2',NULL,'172.19.0.2','Mozilla/5.0 (X11; Linux x86_64; rv:147.0) Gecko/20100101 Firefox/147.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiaHZ2Sno4ZmMyQWxJaGpoYTBEckQ1c3RXeGlJb2VZT0hkZ2pqRDJvMSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvZmF2b3JpdGVzIjtzOjU6InJvdXRlIjtzOjk6ImZhdm9yaXRlcyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771879814),
('fRDcVuPklUZ4dXHab4e83aHm0xutpGgEik4iyuSF',NULL,'172.28.0.1','axios/1.12.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNk95cjRPMzBEMmg4bzVjYWtYcDB4dkUwUkZUbmE1TDVTNTVUUVBtOCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHA6Ly9sb2NhbGhvc3Q6MzI3NzciO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771863105),
('FWzmuJiMcAujaoxieDkkSEozJMNRpMrmgFNTpEp8',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiaWV1VmFXNzBwQ3B2Z2VxYVJuejNUQTBEbmtFQ1didzhhWVdITFBBaiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771865760),
('gdKx2LjhpkK1M2AuvvRs3QE8sV5JCj30sXpbPe1Q',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoia2lNR053WTU0UjBQQ29MNUFMMnFVWWU1dUg5SjFLQlJEOHFHUFdQMCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvZmF2b3JpdGVzIjtzOjU6InJvdXRlIjtzOjk6ImZhdm9yaXRlcyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771879695),
('H1m5fRZ0XvK6xy9BPXrpVSlNkPd63gh6iTwrfvl2',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZEVDRDZTTmxuMG8xNDNGNk9ZZmk2RFlESUxRbzZSVGZYYjhjaThkaiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDU6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvc3BlY2llcy8xMDA0MSI7czo1OiJyb3V0ZSI7czoxNDoic3BlY2llcy5kZXRhaWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1771865782),
('hWBjEy2n2NWtjGji1o7qvjhmaxGVunY1eR6fYWxQ',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiNjVLZ3pyUDhSZkZQWWhaS0pXdlE5MFZCTXlTMzVVYk56S2Q5UFFyNyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDU6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvc3BlY2llcy8yMjgyMyI7czo1OiJyb3V0ZSI7czoxNDoic3BlY2llcy5kZXRhaWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1771879523),
('IvVXRNOZR5ni96ecTH79ONDGKgXLJRO4njONMURn',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiako3RXp2TGpjMEp1a3Q4TldQdHMxM2t1MjRqTGpSUHJCTnZuSjR2aiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvZmF2b3JpdGVzIjtzOjU6InJvdXRlIjtzOjk6ImZhdm9yaXRlcyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771879824),
('iZFC7lLZ69j6DhiYXRvPqgGZIIoPRNuEYX7kZxVW',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiRXBKOG1tNUxoTkR6MmpBYnNuTGdjUVl3ZjR1R3lrWmo3VVZsbjhuNCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771879521),
('j9mHFYjAAHnKrdiBALfdzGnDrmAj8fL80y1EOtU3',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiV2tQVjAwVkxqSDhpaUVneWE5RTBrSHljdUJHZHNGNk9ydVJYNmVTZSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NjI6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvYXNzZXNzbWVudHMvc3lzdGVtL3RlcnJlc3RyaWFsIjtzOjU6InJvdXRlIjtzOjExOiJhc3Nlc3NtZW50cyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771866842),
('juK4ZHtvBTD3RbYo72Qq4CrkLiXZfMHzs56I1bFI',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoic21UQ3Q1QjdxT2lDTGhtSHpkUnhOZHZSRHllQzVZUWJyZGxpZ1VBWCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771866818),
('KGFE8arm6YUjwGzW0NEcoHqRM4dkYa4cOncZRaVp',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQXVhQjR0TUhBbm0wVFI4UWdscG1FdHV2ZVo1ZEdBeTVnejhCWXNzcSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDU6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvc3BlY2llcy8yMjgyMyI7czo1OiJyb3V0ZSI7czoxNDoic3BlY2llcy5kZXRhaWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1771879758),
('kM0gKQcde8oNlHxxilhvaeaWRCK1htvXVYkBEaoR',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoibGhoWXB1NGdyZzdNTlRKdTgyRG5ISG9MdUIxVnJ3Rk5RUEhHQk5oWCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDU6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvc3BlY2llcy8yMjgyMyI7czo1OiJyb3V0ZSI7czoxNDoic3BlY2llcy5kZXRhaWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1771866818),
('knJbyWMcurvHkHugGcP0RAg2Q3MD44m3TPSF8iQw',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiM1h4OGx2QXh0UHk0dlpqWTk4NmJ2S2JYQVpCd3dRbmh0RDJMNVpXcCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvZmF2b3JpdGVzIjtzOjU6InJvdXRlIjtzOjk6ImZhdm9yaXRlcyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771865781),
('KpGsm7AWzeTHU7ZcydvpxNDzQFPoioa55lvnmNjL',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiRnZ1dmVqUDlDR3R0UFh0SkFoSDVQZGg2TTQ4N3U3dXhFekFFUUJFUCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771865162),
('ky0aO3VyrXAi8kHr6oizN4BubiqPNG136YNjbl0P',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoicTA4Z3ZCS0hxd3FjZEZnOTcyaWl0a1R4SmdlSlVwM0tWZzR2ZldXRSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvZmF2b3JpdGVzIjtzOjU6InJvdXRlIjtzOjk6ImZhdm9yaXRlcyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771866010),
('LnVA0yQzPF29mbcElfSRgtFxIeplT7ur1ZwIgfkh',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiWkpvYVV1dFVHcUZDelduY2ZadFpzU0t0SkthZGtYRWo3aVF3Vm4ySCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvZmF2b3JpdGVzIjtzOjU6InJvdXRlIjtzOjk6ImZhdm9yaXRlcyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771866783),
('N4EBZ7iv1WoGsKuG3hD7OpzMHQVsYQeFGTFb315u',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoicmp1T3dFaElxZFVWaWtPejFJS0lVbDZ4dk43VEF6WXZxeWdyMVYySSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDQ6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvYXNzZXNzbWVudC8xIjtzOjU6InJvdXRlIjtzOjE3OiJhc3Nlc3NtZW50LmRldGFpbCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771866843),
('NFfjaOGhjE2FXJurZTnYfQy9dpuV8tVktpDyOBzJ',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVUVOUHEyYVBuV1ZzbXQwajA3dnRQdGJaemlKQkxRajN4ZVgxSUh3SiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvZmF2b3JpdGVzIjtzOjU6InJvdXRlIjtzOjk6ImZhdm9yaXRlcyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771866073),
('O3iu8bVdVb3cWJftBD9CUx4V8O6WZb70hFtuLntd',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYkhSejFjaTJOME9lNVBrMWJISlpmMmJ5VFBNQUJGR0ltcGhBU3U0OSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771866782),
('OVeJ9waLzaArVAvSBPKcbplI7VZnWT2X45e5dG78',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVWQxMmxzcVNZNkI0SEVwQnJVdGtIaXB5SHgyeFI4Wnc2Y3pDcW5kNyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771865163),
('PG9TtvYRYzM5ldVF62SD8VOizBttFxcJjuaB3tcG',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoidmNjQ1VvTGdadUx2ZTRNN0owSks4RXRLYjdpTTRuTk5hc2RuRmlCYyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvZmF2b3JpdGVzIjtzOjU6InJvdXRlIjtzOjk6ImZhdm9yaXRlcyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771879756),
('PnMXXdA24zE9TodBjCifGjcHjf37uypN2JgNcVrt',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiam5FV2JXcWR5T1dMbWh5M3lET3JoWmFGQU9oS1NBQ1VCeXF2a3UwUCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDU6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvc3BlY2llcy8yMjgyMyI7czo1OiJyb3V0ZSI7czoxNDoic3BlY2llcy5kZXRhaWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1771866799),
('po5zIuj3wwdeTZGjh1Wmfi5BGdrFCK1EcrMMNZKQ',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiY2FISWd3czZYaXNSQkdHRFlFOEtBZzRSWHlBeE9nU2VreTBTZURGayI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDU6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvc3BlY2llcy8yMjgyMyI7czo1OiJyb3V0ZSI7czoxNDoic3BlY2llcy5kZXRhaWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1771866106),
('qBLJRc1a2kJTV5c6y29jY0v2PsINTszOnFSxl5fZ',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiU2FLS3l2SXg2QzVSZDNpZ3d5dklncHFzVEFiRGpiMXM2Y1NqQjhjaSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvZmF2b3JpdGVzIjtzOjU6InJvdXRlIjtzOjk6ImZhdm9yaXRlcyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771866818),
('qJYJpk8PXliv5FoAZXhPRVii3piRxhmsgMByF14r',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoibDBJMzRZaVF1UkEyc1dvZlpPT3JSUkVtRWVDRmdmazhGV1RPck9kWSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTQ6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvYXNzZXNzbWVudHMvY291bnRyeS9JVCI7czo1OiJyb3V0ZSI7czoxMToiYXNzZXNzbWVudHMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1771865165),
('QklswjyO7L2l2Clw5fKwJ3iVh6Cj80pIDyxf0Oez',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQXJoV0s0UVZRR29JR3JwTFR5WEpVWktINjBqNmZwcklqOVg5Z2dEeSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771879755),
('qQVDIQ1Ng6Hh73nbruytjw5Evkktsx9MvWHzP45U',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiaVJkMkdBT0JPRW5OQUpZWloybmM2SEFST2JEaHFoMGZxTHFEdmx5cCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771865153),
('rJqDcdoxmRYJ3ov3b0rbHCs95krymb8DSmHXK6OL',NULL,'172.28.0.1','axios/1.12.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUVhEazRQbWVGbjE5NDRBSHBUVVI2bmxISXpjdE8xNVMzakY3NXJNNCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHA6Ly9sb2NhbGhvc3Q6MzI3NzYiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771863105),
('RX2Jx3p2NXK01CsRjgwkdiILDFu7DoQWwbt9H7vY',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiR1hPU20xMVZmSnRqcVNBV256UGFjZXh1NGRGandnUjltV0owck5XNSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771865151),
('siDBjTg3ZtxmhoBTJ6wXpmq1B02IaU6ADczC5vJK',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiTGk0M2pUS3V6empobGhCejNacXhMUHpBZ0h2RlVKZE9nN3NOUGFKbyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NTQ6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvYXNzZXNzbWVudHMvY291bnRyeS9JVCI7czo1OiJyb3V0ZSI7czoxMToiYXNzZXNzbWVudHMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1771866819),
('tHLAkr5S1jGEroZxMo6hnhvAV8taZlGihSjdGMTx',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSjFHa1p6VUo3R3ZBY1htRTNTVWFCNnJtc1lURGVsM3JEaEY3Y2FyciI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDU6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvc3BlY2llcy8yMjgyMyI7czo1OiJyb3V0ZSI7czoxNDoic3BlY2llcy5kZXRhaWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1771866072),
('UM7lNh0unuR05a2KgmxlIsubfqaOJcnRd15S5nEE',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiY0xGMVV1N25FN3VpTEFzdkhVaGdFZ0p3cGk4NVNBR09Pc1JJM0RxNCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDU6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvc3BlY2llcy8yMjgyMyI7czo1OiJyb3V0ZSI7czoxNDoic3BlY2llcy5kZXRhaWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1771879825),
('uRL2v3AAg5DVVYIWo4mtEOLuIQhvECYHaCNCXRyl',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZUdyNm1xMDFQOUwzMXNteDR0MVA1SGRVMjhIVnFBU2ZDNlBSOTdkbCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NjI6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvYXNzZXNzbWVudHMvc3lzdGVtL3RlcnJlc3RyaWFsIjtzOjU6InJvdXRlIjtzOjExOiJhc3Nlc3NtZW50cyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771879825),
('w3W5tC5sKwUg2VR8l2zWeqQ0WHdPyBwfLb5CboeK',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoidHVCMGVFUHFMRktTVGdGSGc2MXZOZWo3Zk4yNnRxVnVBRXdDOVJOeSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDU6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvc3BlY2llcy8yMjgyMyI7czo1OiJyb3V0ZSI7czoxNDoic3BlY2llcy5kZXRhaWwiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1771879697),
('WW7zXUpP2BrjYyviKPdWJBcMeATTUS6M131nLgpe',NULL,'172.19.0.2','axios/1.12.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoiYm5ycGlidTI1b0N3bmxWSGhWNXNYd25aZ3Z2dU9pVlVzSGlBQnVpRiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771863105),
('XfUT3Y8MjTfEjqbxUa8GF3wDL0Kpnyydkz2A3ge7',NULL,'172.19.0.2','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiMVZMVlYyelFtcmtuMnBNSmhWS1RaVGN4Q1FrMjM5U2NuVW5TTFl4NCI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NDE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvZmF2b3JpdGVzIjtzOjU6InJvdXRlIjtzOjk6ImZhdm9yaXRlcyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771864647),
('XU6DIXTEysf9FefDJAIZO4ZADXTd9aMJ37OuMtZ0',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZEUzY2lHUkc0Snh3cE1UeEIwVEl2RmpCajlIVGUzMnNvQWxVc2tyOSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771879695),
('XVUMhxPyugEoicyJP1aTOX33gZGkmUP5DpP4IAKo',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZllvbXZwYk41empUd0RGSDdvNFZmNG9ROHI2ZU5pQk9qdUIwa0dRTyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6NjI6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUvYXNzZXNzbWVudHMvc3lzdGVtL3RlcnJlc3RyaWFsIjtzOjU6InJvdXRlIjtzOjExOiJhc3Nlc3NtZW50cyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1771879697),
('Ygr0TLCQkzxd0hfq6xfgeeP57oN9PW1XnFBORgVt',NULL,'172.19.0.2','curl/8.18.0','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSW5WUGdaQ2lrUWdOcmhiUGlLS0Y0NlV0QktTcHhGV0Y5VHFZZkp5VyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzE6Imh0dHBzOi8vaXVjbi1yZWQtbGlzdC5sbmRvLnNpdGUiO3M6NToicm91dGUiO3M6OToiZGFzaGJvYXJkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1771879824),
('yvPTMOlaRc1n14AOMyUBgc6bclG2VD3Piz0pnzCR',NULL,'172.19.0.2','axios/1.12.1','YTozOntzOjY6Il90b2tlbiI7czo0MDoicTFqTVl2VVVhbUxRaFo5dEZUTVRxaXNyWTRDOWZ0ZEYzMWJ5VDFxdyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly9pdWNuLXJlZC1saXN0LmxuZG8uc2l0ZSI7czo1OiJyb3V0ZSI7czo5OiJkYXNoYm9hcmQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1771863105);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-02-23 20:54:06
